
with open('texto.txt', 'r') as arquivo:
    linhas = arquivo.readlines()
    contagem_linhas = len(linhas)
    print(f"Tem {contagem_linhas} linhas. ")

with open('texto.txt', 'r') as arquivo:
    conteudo = arquivo.read()
    total = len(conteudo)
    print(f"Tem {total} caracteres.")

