alunos = [1,2,3,4,5]

with open('alunos.txt', 'a') as arquivo:
    for a in alunos:
        alunos = input(str(f"Digite o {a}° nome do aluno: "))
        arquivo.write(str(alunos) + '\n')

