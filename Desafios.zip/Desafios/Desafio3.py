import csv

def criar_arquivo():
    with open("produtos.csv", "w", newline="", encoding="utf-8") as arquivo:
        escritor = csv.writer(arquivo)
        escritor.writerow(["nome", "preco"])
    print("Arquivo 'produtos.csv' criado com sucesso!")

def cadastrar_produtos():
    with open("produtos.csv", "a", newline="", encoding="utf-8") as arquivo:
        escritor = csv.writer(arquivo)
        for i in range(3):
            nome = input(f"Digite o nome do produto {i+1}: ")
            preco = float(input(f"Digite o preço do produto {i+1}: "))
            escritor.writerow([nome, preco])
    print("Produtos cadastrados com sucesso!\n")

def exibir_produtos():
    with open("produtos.csv", "r", encoding="utf-8") as arquivo:
        leitor = csv.reader(arquivo)
        next(leitor)  # pula o cabeçalho
        print("Produtos cadastrados:")
        produtos = []
        for linha in leitor:
            produtos.append(linha)
            print(f"Nome: {linha[0]} | Preço: R$ {linha[1]}")
    return produtos

def atualizar_preco():
    produtos = exibir_produtos()
    nome_produto = input("\nDigite o nome do produto que deseja atualizar: ")
    novo_preco = float(input("Digite o novo preço: "))

    for produto in produtos:
        if produto[0].lower() == nome_produto.lower():
            produto[1] = str(novo_preco)
            break
    else:
        print("Produto não encontrado!")
        return

    with open("produtos.csv", "w", newline="", encoding="utf-8") as arquivo:
        escritor = csv.writer(arquivo)
        escritor.writerow(["nome", "preco"])
        escritor.writerows(produtos)

    print("\nPreço atualizado com sucesso!\n")

# Execução do programa
criar_arquivo()
cadastrar_produtos()
atualizar_preco()
exibir_produtos()